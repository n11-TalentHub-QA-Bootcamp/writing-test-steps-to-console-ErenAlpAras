package screenplay.user_interface;


import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl("http://automationpractice.com/index.php")
public class TAPracticeHomePage extends PageObject {
}
